# OpenVault Synthetic Engineer Data Pack

All records are fictional. The `.example` emails are reserved test identifiers, not real accounts; no passwords are included. Hyderabad-area locations and coordinates are illustrative.

## Contents
Each entity is provided as both JSON and CSV:
- users (12 identities/roles; identifiers only, no credentials)
- locations (5 sites with approximate coordinates)
- resources (30 assets with types, conditions, statuses, custodians, departments, values, dates and tags)
- bookings (40 requests with requester/approver and lifecycle timestamps)
- incidents (26 incidents with severity/status, reporter/assignee, resource/location and optional booking links)
- feedback (35 entries with overall and sub-ratings from 1–5 and comments)
- policies (3 policies)
- policy_acknowledgements (6 statuses)
- audit_events (30 synthetic events)

## Suggested import order
users, locations, resources, policies, bookings, incidents, feedback, policy_acknowledgements, audit_events. Adjust to the actual Prisma foreign-key constraints.

## Important
This is an engineer-friendly interchange pack, NOT a verified direct Prisma seed. The repository's current Prisma schema was not accessible from this chat, so field names/enums must be mapped and validated before import. Use only a dedicated development/test database; do not import into production. `evidence_file_ids` are placeholder IDs; no attachment binaries are included. No real passwords are supplied, so these identities will not log in unless test users are created in the application.
